@extends('layouts.app')


@section('content')
    <github-section></github-section>
@endsection