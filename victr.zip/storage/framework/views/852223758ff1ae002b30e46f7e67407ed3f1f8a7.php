<?php $__env->startSection('content'); ?>
    <div class="repository-details">
        <h1 class="text-center repo-name"><?php echo e($repo->name); ?> ( Owner: <?php echo e($repo->owner); ?>)</h1>
        <p class="text-center">
            <?php echo e($repo->description); ?>

        </p>

        <h2 class="text-center">Repository details:</h2>
        <div class="row">
            <div class="col-sm-4 text-center">
                <div class="repo-detail">
                    <h4><strong>Repository ID:</strong></h4>
                    <p><?php echo e($repo->repository_id); ?></p>
                </div>
            </div>
            <div class="col-sm-4 text-center">
                <div class="repo-detail">
                    <h4><strong>Github URL:</strong></h4>
                    <p><a href="<?php echo e($repo->url); ?>"></a><?php echo e($repo->url); ?></p>
                </div>
            </div>
            <div class="col-sm-4 text-center">
                <div class="repo-detail">
                    <h4><strong>Created</strong></h4>
                    <p><?php echo e($repo->created); ?> ( <?php echo e($repo->creted_date_for_humans()); ?> )</p>
                </div>
            </div>
            <div class="col-sm-4 text-center">
                <div class="repo-detail">
                    <h4><strong>Last Push date:</strong></h4>
                    <p><?php echo e($repo->last_push); ?> ( <?php echo e($repo->last_push_date_for_humans()); ?> )</p>
                </div>
            </div>
            <div class="col-sm-4 text-center">
                <div class="repo-detail">
                    <h4><strong>Number of stars</strong></h4>
                    <p><?php echo e($repo->stars); ?></p>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>