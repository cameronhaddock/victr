<?php $__env->startSection('content'); ?>
    <div class="fetch-wrapper">
        <h1>Fetch Repositories from Github</h1>
        <form action="<?php echo e(route('repositories.save')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="form-group col-sm-3">
                <input class="form-control" type="text" placeholder="Pages to fetch" name="count" value="1">
                <span>Each page contains 30 repositories</span>
            </div>
            <input class="btn btn-primary" type="submit" value="Fetch">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>