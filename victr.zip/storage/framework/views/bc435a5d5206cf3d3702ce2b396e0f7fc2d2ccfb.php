<?php $__env->startSection('content'); ?>

    <h1>Repositories</h1>
    <div class="repo-list">
        <?php $__empty_1 = true; $__currentLoopData = $repos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="repo">
                <div class="meta">
                    <a href="<?php echo e(route('repositories.show',['name'=>$repo->name])); ?>"><h3 class="repo-name"><?php echo e($repo->name); ?></h3></a>
                    <p class="description"><?php echo e($repo->description); ?></p>
                    <div class="pin-bottom">
                        <p class="text-muted">updated <?php echo e($repo->last_push_date_for_humans()); ?></p>
                    </div>
                </div>
                <div class="stats">
                    <div class="stars">
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="star-count"><?php echo e($repo->stars); ?></span>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>No result found in local database</p>
            Please goto The <a href="<?php echo e(route('repositories.fetch')); ?>">fetch</a> page to import from github
        <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>